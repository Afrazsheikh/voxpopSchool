export const environment = {
  production: true,
  schoolId: '63c18768f5d8ca52c4ed3d07', 
  apiBaseUrl: 'http://13.126.126.170/api/v1/',
  imageBaseUrl: 'http://13.126.126.170/api/v1/uploads/',
  documentUrl: 'http://13.126.126.170/api/v1/documents/',
  // imageBaseUrl: 'http://ec2-52-63-120-208.ap-southeast-2.compute.amazonaws.com:3030/uploads/',
  // documentUrl: 'http://ec2-52-63-120-208.ap-southeast-2.compute.amazonaws.com:3030/documents/'


};
